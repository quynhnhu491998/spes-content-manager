'use client'

import React, { useState, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle } from 'lucide-react'
import { cn } from '@/lib/utils'

interface FileUploadProps {
  onUploadSuccess: (products: any[]) => void
  onUploadError: (error: string) => void
}

export function FileUpload({ onUploadSuccess, onUploadError }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle')
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    
    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      handleFileUpload(files[0])
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      handleFileUpload(files[0])
    }
  }

  const handleFileUpload = async (file: File) => {
    // Validate file type
    const allowedTypes = [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-excel',
      'text/csv'
    ]

    if (!allowedTypes.includes(file.type)) {
      onUploadError('Vui lòng chọn file Excel (.xlsx, .xls) hoặc CSV')
      setUploadStatus('error')
      return
    }

    setIsUploading(true)
    setUploadStatus('idle')

    try {
      const formData = new FormData()
      formData.append('file', file)

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || 'Upload failed')
      }

      setUploadStatus('success')
      onUploadSuccess(result.products)
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
    } catch (error) {
      console.error('Upload error:', error)
      setUploadStatus('error')
      onUploadError(error instanceof Error ? error.message : 'Upload failed')
    } finally {
      setIsUploading(false)
    }
  }

  const openFileDialog = () => {
    fileInputRef.current?.click()
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileSpreadsheet className="w-5 h-5" />
          Upload File Sản Phẩm
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div
          className={cn(
            "border-2 border-dashed rounded-lg p-8 text-center transition-colors",
            isDragging ? "border-blue-500 bg-blue-50" : "border-gray-300",
            isUploading && "opacity-50 pointer-events-none"
          )}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            onChange={handleFileSelect}
            className="hidden"
          />

          <div className="flex flex-col items-center gap-4">
            {uploadStatus === 'success' ? (
              <CheckCircle className="w-12 h-12 text-green-500" />
            ) : uploadStatus === 'error' ? (
              <AlertCircle className="w-12 h-12 text-red-500" />
            ) : (
              <Upload className="w-12 h-12 text-gray-400" />
            )}

            <div>
              <h3 className="text-lg font-semibold mb-2">
                {isUploading ? 'Đang upload...' : 'Kéo thả file hoặc click để chọn'}
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                Hỗ trợ file Excel (.xlsx, .xls) và CSV
              </p>
              
              <Button 
                onClick={openFileDialog}
                disabled={isUploading}
                variant="outline"
              >
                {isUploading ? 'Đang xử lý...' : 'Chọn File'}
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-4 text-sm text-gray-600">
          <h4 className="font-semibold mb-2">Định dạng file yêu cầu:</h4>
          <ul className="list-disc list-inside space-y-1">
            <li><strong>Tên SP:</strong> Tên sản phẩm (bắt buộc)</li>
            <li><strong>Giá:</strong> Giá bán (bắt buộc)</li>
            <li><strong>Phân loại:</strong> Loại sản phẩm (bắt buộc)</li>
            <li><strong>Mô tả:</strong> Mô tả sản phẩm (tùy chọn)</li>
            <li><strong>Ảnh:</strong> URL hình ảnh (tùy chọn)</li>
            <li><strong>Mã SKU:</strong> Mã sản phẩm (tùy chọn)</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}

