'use client'

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ShoppingBag, Download, AlertCircle, CheckCircle } from 'lucide-react'

interface ShopeeImportProps {
  onImportSuccess: (products: any[]) => void
  onImportError: (error: string) => void
}

export function ShopeeImport({ onImportSuccess, onImportError }: ShopeeImportProps) {
  const [shopUrl, setShopUrl] = useState('https://shopee.vn/spesvietnam')
  const [isImporting, setIsImporting] = useState(false)
  const [importStatus, setImportStatus] = useState<'idle' | 'success' | 'error'>('idle')

  const handleImport = async (useMockData = false) => {
    setIsImporting(true)
    setImportStatus('idle')

    try {
      const response = await fetch('/api/shopee/scrape', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          shopUrl: useMockData ? '' : shopUrl,
          useMockData
        })
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || 'Import failed')
      }

      setImportStatus('success')
      onImportSuccess(result.products)
    } catch (error) {
      console.error('Import error:', error)
      setImportStatus('error')
      onImportError(error instanceof Error ? error.message : 'Import failed')
    } finally {
      setIsImporting(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShoppingBag className="w-5 h-5" />
          Import từ Shopee
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">
            URL Shop Shopee
          </label>
          <Input
            type="url"
            value={shopUrl}
            onChange={(e) => setShopUrl(e.target.value)}
            placeholder="https://shopee.vn/spesvietnam"
            disabled={isImporting}
          />
        </div>

        <div className="flex gap-2">
          <Button 
            onClick={() => handleImport(false)}
            disabled={isImporting || !shopUrl}
            className="flex-1"
          >
            <Download className="w-4 h-4 mr-2" />
            {isImporting ? 'Đang import...' : 'Import từ Shopee'}
          </Button>
          
          <Button 
            onClick={() => handleImport(true)}
            disabled={isImporting}
            variant="outline"
            className="flex-1"
          >
            <Download className="w-4 h-4 mr-2" />
            Dùng dữ liệu mẫu
          </Button>
        </div>

        {importStatus === 'success' && (
          <div className="flex items-center gap-2 text-green-600 text-sm">
            <CheckCircle className="w-4 h-4" />
            Import thành công!
          </div>
        )}

        {importStatus === 'error' && (
          <div className="flex items-center gap-2 text-red-600 text-sm">
            <AlertCircle className="w-4 h-4" />
            Có lỗi xảy ra khi import
          </div>
        )}

        <div className="text-sm text-gray-600">
          <h4 className="font-semibold mb-2">Lưu ý:</h4>
          <ul className="list-disc list-inside space-y-1">
            <li>Shopee có thể chặn việc scraping tự động</li>
            <li>Sử dụng "Dữ liệu mẫu" để test chức năng</li>
            <li>Dữ liệu mẫu dựa trên sản phẩm SPES thực tế</li>
            <li>Chỉ admin (manus@gmail.com) mới có thể import</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}

