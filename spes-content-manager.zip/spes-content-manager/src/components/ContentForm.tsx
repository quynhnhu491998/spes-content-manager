'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { 
  Lightbulb, 
  RefreshCw, 
  Save, 
  Copy, 
  Download,
  Sparkles,
  Target,
  Hash,
  MessageSquare
} from 'lucide-react'
import { generateHashtags, getRandomHook, getRandomCTA, toneOptions } from '@/lib/utils'

interface Product {
  id: string
  name: string
  price: string
  category: string
  description?: string
  image?: string
}

interface ContentFormProps {
  product: Product
  onSave: (content: any) => void
  onBack: () => void
}

const contentFormulas = [
  {
    name: 'AIDA',
    description: 'Attention - Interest - Desire - Action',
    template: `🔥 [Hook thu hút sự chú ý]

💡 [Giải thích lợi ích và tạo hứng thú]

✨ [Tạo mong muốn sở hữu sản phẩm]

👉 [Call to Action rõ ràng]`
  },
  {
    name: 'PAS',
    description: 'Problem - Agitate - Solution',
    template: `😰 [Nêu vấn đề khách hàng gặp phải]

💔 [Khuếch đại vấn đề, tạo cảm xúc]

🌟 [Giới thiệu sản phẩm như giải pháp]

👉 [Call to Action]`
  },
  {
    name: '4P',
    description: 'Promise - Picture - Proof - Push',
    template: `🎯 [Lời hứa về kết quả]

🖼️ [Mô tả hình ảnh tương lai tích cực]

✅ [Bằng chứng, chứng minh]

🚀 [Thúc đẩy hành động ngay]`
  },
  {
    name: 'Storytelling',
    description: 'Kể chuyện có cảm xúc',
    template: `📖 [Mở đầu câu chuyện]

🎭 [Phát triển tình huống, xung đột]

🌈 [Giải quyết bằng sản phẩm]

💝 [Kết thúc có ý nghĩa + CTA]`
  }
]

export function ContentForm({ product, onSave, onBack }: ContentFormProps) {
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [hashtags, setHashtags] = useState<string[]>([])
  const [tone, setTone] = useState('natural')
  const [cta, setCta] = useState('')
  const [selectedFormula, setSelectedFormula] = useState(contentFormulas[0])
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    // Generate initial suggestions
    generateInitialSuggestions()
  }, [product])

  const generateInitialSuggestions = () => {
    const suggestedHashtags = generateHashtags(product.name, product.category)
    setHashtags(suggestedHashtags)
    setCta(getRandomCTA())
  }

  const handleGenerateHook = () => {
    const hook = getRandomHook()
    setTitle(hook)
  }

  const handleGenerateCTA = () => {
    const newCta = getRandomCTA()
    setCta(newCta)
  }

  const handleGenerateHashtags = () => {
    const newHashtags = generateHashtags(product.name, product.category)
    setHashtags(newHashtags)
  }

  const handleUseFormula = (formula: typeof contentFormulas[0]) => {
    setSelectedFormula(formula)
    setContent(formula.template)
  }

  const handleSave = async () => {
    if (!title.trim() || !content.trim()) {
      alert('Vui lòng nhập tiêu đề và nội dung')
      return
    }

    setIsSaving(true)
    try {
      const postData = {
        title: title.trim(),
        content: content.trim(),
        hashtags: hashtags.join(' '),
        tone,
        cta: cta.trim(),
        productId: product.id
      }

      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(postData)
      })

      if (response.ok) {
        const savedPost = await response.json()
        onSave(savedPost)
      } else {
        throw new Error('Failed to save post')
      }
    } catch (error) {
      console.error('Error saving post:', error)
      alert('Có lỗi xảy ra khi lưu bài viết')
    } finally {
      setIsSaving(false)
    }
  }

  const handleCopyContent = () => {
    const fullContent = `${title}\n\n${content}\n\n${hashtags.join(' ')}\n\n${cta}`
    navigator.clipboard.writeText(fullContent)
    alert('Đã copy nội dung!')
  }

  const handleExportTxt = () => {
    const fullContent = `Tiêu đề: ${title}\n\nNội dung:\n${content}\n\nHashtags: ${hashtags.join(' ')}\n\nTone: ${tone}\n\nCTA: ${cta}\n\nSản phẩm: ${product.name}\nGiá: ${product.price}\nDanh mục: ${product.category}`
    
    const blob = new Blob([fullContent], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `content-${product.name.replace(/[^a-zA-Z0-9]/g, '-')}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const addHashtag = (tag: string) => {
    if (!hashtags.includes(tag)) {
      setHashtags([...hashtags, tag])
    }
  }

  const removeHashtag = (tag: string) => {
    setHashtags(hashtags.filter(h => h !== tag))
  }

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <Button variant="outline" onClick={onBack}>
            ← Quay lại
          </Button>
        </div>
        <div className="text-center">
          <h1 className="text-2xl font-bold">Viết Content Facebook</h1>
          <p className="text-gray-600">{product.name}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleCopyContent}>
            <Copy className="w-4 h-4 mr-2" />
            Copy
          </Button>
          <Button variant="outline" onClick={handleExportTxt}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Product Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Thông tin sản phẩm
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><strong>Tên:</strong> {product.name}</div>
                <div><strong>Giá:</strong> {product.price}</div>
                <div><strong>Danh mục:</strong> {product.category}</div>
                <div><strong>Mô tả:</strong> {product.description || 'Không có'}</div>
              </div>
            </CardContent>
          </Card>

          {/* Title */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  Tiêu đề Facebook
                </span>
                <Button variant="outline" size="sm" onClick={handleGenerateHook}>
                  <Lightbulb className="w-4 h-4 mr-2" />
                  Gợi ý Hook
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Input
                placeholder="Nhập tiêu đề thu hút..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="text-lg"
              />
            </CardContent>
          </Card>

          {/* Content */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Nội dung bài viết
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Viết nội dung bài viết của bạn..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={12}
                className="text-base"
              />
              
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Tone giọng:</span>
                <Select value={tone} onValueChange={setTone}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {toneOptions.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Hashtags */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Hash className="w-5 h-5" />
                  Hashtags
                </span>
                <Button variant="outline" size="sm" onClick={handleGenerateHashtags}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Tạo mới
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {hashtags.map(tag => (
                  <Badge 
                    key={tag} 
                    variant="secondary" 
                    className="cursor-pointer hover:bg-red-100"
                    onClick={() => removeHashtag(tag)}
                  >
                    {tag} ×
                  </Badge>
                ))}
              </div>
              
              <Input
                placeholder="Thêm hashtag mới..."
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    const value = e.currentTarget.value.trim()
                    if (value) {
                      addHashtag(value.startsWith('#') ? value : `#${value}`)
                      e.currentTarget.value = ''
                    }
                  }
                }}
              />
            </CardContent>
          </Card>

          {/* CTA */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Call to Action</span>
                <Button variant="outline" size="sm" onClick={handleGenerateCTA}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Gợi ý mới
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Nhập call to action..."
                value={cta}
                onChange={(e) => setCta(e.target.value)}
                rows={3}
              />
            </CardContent>
          </Card>

          {/* Save Button */}
          <Button 
            onClick={handleSave} 
            disabled={isSaving}
            className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-lg py-6"
          >
            <Save className="w-5 h-5 mr-2" />
            {isSaving ? 'Đang lưu...' : 'Lưu bài viết'}
          </Button>
        </div>

        {/* Sidebar - Content Formulas */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Công thức viết bài</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {contentFormulas.map(formula => (
                <div key={formula.name} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold">{formula.name}</h3>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleUseFormula(formula)}
                    >
                      Sử dụng
                    </Button>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{formula.description}</p>
                  <pre className="text-xs bg-gray-50 p-2 rounded whitespace-pre-wrap">
                    {formula.template}
                  </pre>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Tips */}
          <Card>
            <CardHeader>
              <CardTitle>💡 Tips viết content</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div>• Sử dụng emoji để thu hút sự chú ý</div>
              <div>• Đặt câu hỏi để tương tác với khách hàng</div>
              <div>• Kể câu chuyện có cảm xúc</div>
              <div>• Tạo cảm giác khan hiếm, cấp bách</div>
              <div>• Sử dụng số liệu cụ thể</div>
              <div>• Call to action rõ ràng, dễ hiểu</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

