'use client'

import React from 'react'
import { Card, CardContent, CardFooter } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Edit, Trash2, ExternalLink } from 'lucide-react'
import Image from 'next/image'

interface Product {
  id: string
  name: string
  price: string
  category: string
  description?: string
  image?: string
  source: string
  sourceUrl?: string
  createdAt: string
}

interface ProductCardProps {
  product: Product
  onEdit: (product: Product) => void
  onDelete: (productId: string) => void
  onCreateContent: (product: Product) => void
}

export function ProductCard({ product, onEdit, onDelete, onCreateContent }: ProductCardProps) {
  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement>) => {
    e.currentTarget.src = '/images/placeholder.jpg'
  }

  return (
    <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
      <CardContent className="p-4">
        <div className="aspect-square relative mb-4 overflow-hidden rounded-lg bg-gray-100">
          {product.image ? (
            <Image
              src={product.image}
              alt={product.name}
              fill
              className="object-cover transition-transform duration-300 group-hover:scale-105"
              onError={handleImageError}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
              <span className="text-gray-400 text-sm">Không có ảnh</span>
            </div>
          )}
          
          {/* Source badge */}
          <Badge 
            variant={product.source === 'shopee' ? 'default' : 'secondary'}
            className="absolute top-2 right-2"
          >
            {product.source === 'shopee' ? 'Shopee' : 'File'}
          </Badge>
        </div>

        <div className="space-y-2">
          <h3 className="font-semibold text-lg line-clamp-2 min-h-[3.5rem]">
            {product.name}
          </h3>
          
          <div className="flex items-center justify-between">
            <span className="text-xl font-bold text-green-600">
              {product.price}
            </span>
            <Badge variant="outline">
              {product.category}
            </Badge>
          </div>

          {product.description && (
            <p className="text-sm text-gray-600 line-clamp-2">
              {product.description}
            </p>
          )}
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0 flex flex-col gap-2">
        <Button 
          onClick={() => onCreateContent(product)}
          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          <Edit className="w-4 h-4 mr-2" />
          Viết Content
        </Button>
        
        <div className="flex gap-2 w-full">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onEdit(product)}
            className="flex-1"
          >
            <Edit className="w-4 h-4 mr-1" />
            Sửa
          </Button>
          
          {product.sourceUrl && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => window.open(product.sourceUrl, '_blank')}
              className="flex-1"
            >
              <ExternalLink className="w-4 h-4 mr-1" />
              Xem
            </Button>
          )}
          
          <Button 
            variant="destructive" 
            size="sm" 
            onClick={() => onDelete(product.id)}
            className="flex-1"
          >
            <Trash2 className="w-4 h-4 mr-1" />
            Xóa
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}

