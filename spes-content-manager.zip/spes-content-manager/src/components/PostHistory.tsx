'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  History, 
  Edit, 
  Trash2, 
  Copy, 
  Download,
  Calendar,
  Tag,
  MessageSquare
} from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { vi } from 'date-fns/locale'

interface Post {
  id: string
  title: string
  content: string
  hashtags?: string
  tone: string
  cta?: string
  createdAt: string
  updatedAt: string
  product: {
    id: string
    name: string
    category: string
  }
}

interface PostHistoryProps {
  productId?: string
  onEdit?: (post: Post) => void
}

export function PostHistory({ productId, onEdit }: PostHistoryProps) {
  const [posts, setPosts] = useState<Post[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [expandedPost, setExpandedPost] = useState<string | null>(null)

  useEffect(() => {
    fetchPosts()
  }, [productId])

  const fetchPosts = async () => {
    try {
      const url = productId ? `/api/posts?productId=${productId}` : '/api/posts'
      const response = await fetch(url)
      
      if (response.ok) {
        const data = await response.json()
        setPosts(data)
      }
    } catch (error) {
      console.error('Error fetching posts:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleDelete = async (postId: string) => {
    if (!confirm('Bạn có chắc chắn muốn xóa bài viết này?')) return

    try {
      const response = await fetch(`/api/posts?id=${postId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setPosts(posts.filter(p => p.id !== postId))
      }
    } catch (error) {
      console.error('Error deleting post:', error)
    }
  }

  const handleCopy = (post: Post) => {
    const fullContent = `${post.title}\n\n${post.content}\n\n${post.hashtags || ''}\n\n${post.cta || ''}`
    navigator.clipboard.writeText(fullContent)
    alert('Đã copy nội dung!')
  }

  const handleExport = (post: Post) => {
    const fullContent = `Tiêu đề: ${post.title}\n\nNội dung:\n${post.content}\n\nHashtags: ${post.hashtags || ''}\n\nTone: ${post.tone}\n\nCTA: ${post.cta || ''}\n\nSản phẩm: ${post.product.name}\nDanh mục: ${post.product.category}\n\nTạo lúc: ${new Date(post.createdAt).toLocaleString('vi-VN')}`
    
    const blob = new Blob([fullContent], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `post-${post.id}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const toggleExpanded = (postId: string) => {
    setExpandedPost(expandedPost === postId ? null : postId)
  }

  const getToneLabel = (tone: string) => {
    const toneMap: { [key: string]: string } = {
      natural: 'Tự nhiên',
      fun: 'Vui vẻ',
      review: 'Review',
      expert: 'Chuyên gia',
      sales: 'Kích thích mua hàng'
    }
    return toneMap[tone] || tone
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="w-5 h-5" />
            Lịch sử bài viết
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-2/3"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <History className="w-5 h-5" />
          Lịch sử bài viết ({posts.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {posts.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Chưa có bài viết nào</p>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map(post => (
              <div key={post.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 
                      className="font-semibold text-lg cursor-pointer hover:text-blue-600"
                      onClick={() => toggleExpanded(post.id)}
                    >
                      {post.title}
                    </h3>
                    <p className="text-sm text-gray-600 mt-1">
                      {post.product.name} • {post.product.category}
                    </p>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleCopy(post)}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleExport(post)}
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                    {onEdit && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => onEdit(post)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    )}
                    <Button 
                      variant="destructive" 
                      size="sm"
                      onClick={() => handleDelete(post.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {formatDistanceToNow(new Date(post.createdAt), { 
                      addSuffix: true, 
                      locale: vi 
                    })}
                  </div>
                  <Badge variant="outline">
                    {getToneLabel(post.tone)}
                  </Badge>
                </div>

                {expandedPost === post.id && (
                  <div className="space-y-3 pt-3 border-t">
                    <div>
                      <h4 className="font-medium mb-2">Nội dung:</h4>
                      <p className="text-sm whitespace-pre-wrap bg-gray-50 p-3 rounded">
                        {post.content}
                      </p>
                    </div>

                    {post.hashtags && (
                      <div>
                        <h4 className="font-medium mb-2">Hashtags:</h4>
                        <div className="flex flex-wrap gap-1">
                          {post.hashtags.split(' ').filter(tag => tag.trim()).map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {post.cta && (
                      <div>
                        <h4 className="font-medium mb-2">Call to Action:</h4>
                        <p className="text-sm bg-blue-50 p-3 rounded">
                          {post.cta}
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

