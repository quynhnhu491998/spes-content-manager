import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '../../auth/[...nextauth]/route'
import { ShopeeScraper } from '@/lib/shopee-scraper'
import { prisma } from '@/lib/prisma'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check if user is admin
    if (session.user.email !== process.env.ADMIN_EMAIL) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    const body = await request.json()
    const { shopUrl, useMockData } = body

    const scraper = new ShopeeScraper()
    let products

    if (useMockData) {
      // Use mock data for demonstration
      products = await scraper.getMockSpesProducts()
    } else {
      // Try to scrape real data
      if (!shopUrl) {
        return NextResponse.json({ error: 'Shop URL required' }, { status: 400 })
      }
      products = await scraper.scrapeShopProducts(shopUrl)
    }

    // Save products to database
    const savedProducts = []
    for (const product of products) {
      try {
        const savedProduct = await prisma.product.create({
          data: {
            name: product.name,
            price: product.price,
            category: product.category,
            description: product.description,
            image: product.image,
            source: 'shopee',
            sourceUrl: product.sourceUrl,
            userId: session.user.id
          }
        })
        savedProducts.push(savedProduct)
      } catch (error) {
        console.error('Error saving product:', error)
      }
    }

    return NextResponse.json({
      message: `Successfully scraped and saved ${savedProducts.length} products`,
      products: savedProducts
    })
  } catch (error) {
    console.error('Error scraping Shopee:', error)
    return NextResponse.json({ 
      error: 'Failed to scrape products',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}

