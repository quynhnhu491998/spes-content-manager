import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '../auth/[...nextauth]/route'
import { prisma } from '@/lib/prisma'
import * as XLSX from 'xlsx'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check if user is admin
    if (session.user.email !== process.env.ADMIN_EMAIL) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    const formData = await request.formData()
    const file = formData.get('file') as File

    if (!file) {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 })
    }

    // Check file type
    const allowedTypes = [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
      'application/vnd.ms-excel', // .xls
      'text/csv' // .csv
    ]

    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json({ 
        error: 'Invalid file type. Please upload Excel (.xlsx, .xls) or CSV file.' 
      }, { status: 400 })
    }

    // Read file content
    const buffer = await file.arrayBuffer()
    const workbook = XLSX.read(buffer, { type: 'buffer' })
    const sheetName = workbook.SheetNames[0]
    const worksheet = workbook.Sheets[sheetName]
    const jsonData = XLSX.utils.sheet_to_json(worksheet)

    // Process and validate data
    const products = []
    const errors = []

    for (let i = 0; i < jsonData.length; i++) {
      const row = jsonData[i] as any
      
      try {
        // Map common column names (case insensitive)
        const name = row['Tên SP'] || row['Tên sản phẩm'] || row['Name'] || row['Product Name'] || ''
        const price = row['Giá'] || row['Price'] || row['Giá bán'] || ''
        const category = row['Phân loại'] || row['Category'] || row['Loại'] || ''
        const description = row['Mô tả'] || row['Description'] || row['Mô tả sản phẩm'] || ''
        const image = row['Ảnh'] || row['Image'] || row['Hình ảnh'] || ''
        const sku = row['Mã SKU'] || row['SKU'] || row['Mã sản phẩm'] || ''

        if (!name || !price || !category) {
          errors.push(`Row ${i + 1}: Missing required fields (Tên SP, Giá, Phân loại)`)
          continue
        }

        products.push({
          name: String(name).trim(),
          price: String(price).trim(),
          category: String(category).trim(),
          description: String(description).trim(),
          image: String(image).trim(),
          sku: String(sku).trim()
        })
      } catch (error) {
        errors.push(`Row ${i + 1}: Error processing data - ${error}`)
      }
    }

    if (products.length === 0) {
      return NextResponse.json({ 
        error: 'No valid products found in file',
        details: errors
      }, { status: 400 })
    }

    // Save products to database
    const savedProducts = []
    for (const product of products) {
      try {
        const savedProduct = await prisma.product.create({
          data: {
            name: product.name,
            price: product.price,
            category: product.category,
            description: product.description,
            image: product.image,
            sku: product.sku,
            source: 'file',
            sourceUrl: '',
            userId: session.user.id
          }
        })
        savedProducts.push(savedProduct)
      } catch (error) {
        console.error('Error saving product:', error)
        errors.push(`Failed to save product: ${product.name}`)
      }
    }

    return NextResponse.json({
      message: `Successfully uploaded ${savedProducts.length} products`,
      products: savedProducts,
      errors: errors.length > 0 ? errors : undefined
    })
  } catch (error) {
    console.error('Error uploading file:', error)
    return NextResponse.json({ 
      error: 'Failed to process file',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}

