'use client'

import React from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { AlertCircle, Home } from 'lucide-react'

export default function AuthErrorPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const error = searchParams.get('error')

  const getErrorMessage = (error: string | null) => {
    switch (error) {
      case 'AccessDenied':
        return 'Truy cập bị từ chối. Chỉ tài khoản manus@gmail.com mới được phép sử dụng hệ thống này.'
      case 'Configuration':
        return 'Lỗi cấu hình hệ thống. Vui lòng liên hệ quản trị viên.'
      case 'Verification':
        return 'Lỗi xác thực. Vui lòng thử lại.'
      default:
        return 'Có lỗi xảy ra trong quá trình đăng nhập. Vui lòng thử lại.'
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-orange-100">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mb-4">
            <AlertCircle className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl text-red-600">Lỗi đăng nhập</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-center">
          <p className="text-gray-700">
            {getErrorMessage(error)}
          </p>
          
          <Button 
            onClick={() => router.push('/')}
            className="w-full"
          >
            <Home className="w-4 h-4 mr-2" />
            Về trang chủ
          </Button>
          
          <div className="text-sm text-gray-600">
            <p>Nếu bạn là quản trị viên và gặp vấn đề,</p>
            <p>vui lòng kiểm tra cấu hình Google OAuth.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

