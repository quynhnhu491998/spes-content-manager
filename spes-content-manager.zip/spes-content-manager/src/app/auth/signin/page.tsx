'use client'

import React from 'react'
import { signIn, getSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { User, Shield } from 'lucide-react'

export default function SignInPage() {
  const router = useRouter()

  useEffect(() => {
    // Check if already signed in
    getSession().then((session) => {
      if (session) {
        router.push('/')
      }
    })
  }, [router])

  const handleSignIn = () => {
    signIn('google', { callbackUrl: '/' })
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl">SPES Content Manager</CardTitle>
          <p className="text-gray-600">
            Hệ thống quản lý nội dung Facebook cho SPES Vietnam
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button 
            onClick={handleSignIn}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            <User className="w-4 h-4 mr-2" />
            Đăng nhập với Google
          </Button>
          
          <div className="text-center text-sm text-gray-600">
            <p>Chỉ tài khoản được ủy quyền mới có thể truy cập</p>
            <p className="mt-2 font-medium">manus@gmail.com</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

