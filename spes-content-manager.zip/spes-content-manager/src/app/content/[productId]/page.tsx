'use client'

import React, { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { ContentForm } from '@/components/ContentForm'
import { Card, CardContent } from '@/components/ui/card'

interface Product {
  id: string
  name: string
  price: string
  category: string
  description?: string
  image?: string
}

export default function ContentPage() {
  const params = useParams()
  const router = useRouter()
  const { data: session, status } = useSession()
  const [product, setProduct] = useState<Product | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'loading') return
    
    if (!session) {
      router.push('/')
      return
    }

    fetchProduct()
  }, [session, status, params.productId])

  const fetchProduct = async () => {
    try {
      const response = await fetch('/api/products')
      if (!response.ok) {
        throw new Error('Failed to fetch products')
      }

      const products = await response.json()
      const foundProduct = products.find((p: Product) => p.id === params.productId)
      
      if (!foundProduct) {
        setError('Không tìm thấy sản phẩm')
        return
      }

      setProduct(foundProduct)
    } catch (error) {
      console.error('Error fetching product:', error)
      setError('Có lỗi xảy ra khi tải sản phẩm')
    } finally {
      setIsLoading(false)
    }
  }

  const handleSave = (savedPost: any) => {
    alert('Đã lưu bài viết thành công!')
    router.push('/')
  }

  const handleBack = () => {
    router.push('/')
  }

  if (status === 'loading' || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Đang tải...</p>
        </div>
      </div>
    )
  }

  if (!session) {
    return null // Will redirect to home
  }

  if (error || !product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-semibold mb-4">Lỗi</h2>
            <p className="text-gray-600 mb-4">{error || 'Không tìm thấy sản phẩm'}</p>
            <button 
              onClick={handleBack}
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              Quay lại
            </button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <ContentForm 
        product={product}
        onSave={handleSave}
        onBack={handleBack}
      />
    </div>
  )
}

