import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Providers } from './providers'
import { ThemeProvider } from '@/components/ThemeProvider'
import { Toaster } from '@/components/Toaster'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'SPES Content Manager - Quản lý nội dung Facebook',
  description: 'Ứng dụng quản lý sản phẩm và viết content Facebook cho SPES Vietnam',
  keywords: 'SPES, content marketing, Facebook, dầu gội, chăm sóc tóc',
  authors: [{ name: 'SPES Vietnam' }],
  viewport: 'width=device-width, initial-scale=1',
  robots: 'noindex, nofollow', // Private app
  openGraph: {
    title: 'SPES Content Manager',
    description: 'Quản lý sản phẩm và viết content Facebook cho SPES Vietnam',
    type: 'website',
    locale: 'vi_VN',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SPES Content Manager',
    description: 'Quản lý sản phẩm và viết content Facebook cho SPES Vietnam',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="vi" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          defaultTheme="system"
          storageKey="spes-ui-theme"
        >
          <Providers>
            {children}
            <Toaster />
          </Providers>
        </ThemeProvider>
      </body>
    </html>
  )
}

