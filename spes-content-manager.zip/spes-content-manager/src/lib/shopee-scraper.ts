import axios from 'axios'
import * as cheerio from 'cheerio'

export interface ShopeeProduct {
  name: string
  price: string
  category: string
  description: string
  image: string
  sourceUrl: string
}

export class ShopeeScraper {
  private baseUrl = 'https://shopee.vn'
  
  async scrapeShopProducts(shopUrl: string): Promise<ShopeeProduct[]> {
    try {
      // Extract shop username from URL
      const shopUsername = this.extractShopUsername(shopUrl)
      if (!shopUsername) {
        throw new Error('Invalid Shopee shop URL')
      }

      // Get shop page HTML
      const response = await axios.get(shopUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
      })

      const $ = cheerio.load(response.data)
      const products: ShopeeProduct[] = []

      // Try to extract products from the page
      // Note: Shopee uses dynamic loading, so this might need to be adapted
      $('.shop-search-result-view__item, .col-xs-2-4').each((index, element) => {
        try {
          const $element = $(element)
          
          const name = $element.find('.KbqMNq, ._10Wbs-, .Cve6sh').text().trim()
          const price = $element.find('._1d5jk1, .ZEQdwB, ._341bF0').text().trim()
          const imageUrl = $element.find('img').attr('src') || $element.find('img').attr('data-src') || ''
          const productLink = $element.find('a').attr('href') || ''
          
          if (name && price) {
            products.push({
              name: name,
              price: this.cleanPrice(price),
              category: this.categorizeProduct(name),
              description: name, // Use name as description for now
              image: this.normalizeImageUrl(imageUrl),
              sourceUrl: productLink.startsWith('http') ? productLink : `${this.baseUrl}${productLink}`
            })
          }
        } catch (error) {
          console.error('Error parsing product:', error)
        }
      })

      return products
    } catch (error) {
      console.error('Error scraping Shopee:', error)
      throw new Error('Failed to scrape Shopee products')
    }
  }

  // Fallback method using mock data based on the PDF document
  async getMockSpesProducts(): Promise<ShopeeProduct[]> {
    return [
      {
        name: "Dầu gội khô SPES 200ml hương bưởi",
        price: "150,000đ",
        category: "Dầu gội khô",
        description: "Xịt dưỡng tóc tạo phồng cấp tốc, thấm hút dầu không gây bết dính, giữ nếp 8h",
        image: "/images/dau-goi-kho-buoi.jpg",
        sourceUrl: "https://shopee.vn/spesvietnam"
      },
      {
        name: "Dầu gội khô SPES 150ml hương trà bá tước",
        price: "120,000đ",
        category: "Dầu gội khô",
        description: "Xịt dưỡng tóc bồng bềnh cấp tốc, hút dầu không bết dính, giữ nếp 8h",
        image: "/images/dau-goi-kho-tra.jpg",
        sourceUrl: "https://shopee.vn/spesvietnam"
      },
      {
        name: "Dầu gội khô SPES 150ml hương tinh khiết",
        price: "120,000đ",
        category: "Dầu gội khô",
        description: "Dầu gội khô cấp tốc, hút dầu không bết dính, giữ nếp 8h, hương tinh khiết",
        image: "/images/dau-goi-kho-tinh-khiet.jpg",
        sourceUrl: "https://shopee.vn/spesvietnam"
      },
      {
        name: "Dầu gội xịt khô Spes nấm Truffle trắng 100ml",
        price: "100,000đ",
        category: "Dầu gội khô",
        description: "Kiềm dầu tạo phồng với tinh chất nấm Truffle trắng",
        image: "/images/dau-goi-truffle.jpg",
        sourceUrl: "https://shopee.vn/spesvietnam"
      },
      {
        name: "Gôm xịt tóc SPES giữ nếp 200ml",
        price: "180,000đ",
        category: "Keo xịt tạo kiểu",
        description: "Giữ nếp định hình cho tóc bồng bềnh, giữ nếp 48h",
        image: "/images/gom-xit-toc.jpg",
        sourceUrl: "https://shopee.vn/spesvietnam"
      },
      {
        name: "Dầu gội sạch gàu SPES Polypeptide 500ml",
        price: "250,000đ",
        category: "Dầu gội trị gàu",
        description: "Giảm ngứa chống vi khuẩn hại da đầu",
        image: "/images/dau-goi-sach-gau.jpg",
        sourceUrl: "https://shopee.vn/spesvietnam"
      },
      {
        name: "Dầu xả sạch gàu SPES Polypeptide 500ml",
        price: "250,000đ",
        category: "Dầu xả trị gàu",
        description: "Kiềm dầu giảm ngứa, làm sạch dưỡng ẩm tóc",
        image: "/images/dau-xa-sach-gau.jpg",
        sourceUrl: "https://shopee.vn/spesvietnam"
      },
      {
        name: "Dầu gội SPES 300ml tinh chất Tuyết tùng",
        price: "200,000đ",
        category: "Dầu gội dưỡng tóc",
        description: "Dứt điểm gàu ngứa, mẩn đỏ da đầu",
        image: "/images/dau-goi-tuyet-tung.jpg",
        sourceUrl: "https://shopee.vn/spesvietnam"
      },
      {
        name: "Dầu xả phục hồi SPES 300ml tinh chất Tuyết tùng",
        price: "200,000đ",
        category: "Dầu xả dưỡng tóc",
        description: "Tái tạo làm sạch và dưỡng tóc",
        image: "/images/dau-xa-tuyet-tung.jpg",
        sourceUrl: "https://shopee.vn/spesvietnam"
      }
    ]
  }

  private extractShopUsername(url: string): string | null {
    const match = url.match(/shopee\.vn\/([^\/\?]+)/)
    return match ? match[1] : null
  }

  private cleanPrice(price: string): string {
    return price.replace(/[^\d,]/g, '') + 'đ'
  }

  private categorizeProduct(name: string): string {
    const nameLower = name.toLowerCase()
    
    if (nameLower.includes('gội khô') || nameLower.includes('dry shampoo')) {
      return 'Dầu gội khô'
    } else if (nameLower.includes('gôm') || nameLower.includes('keo xịt')) {
      return 'Keo xịt tạo kiểu'
    } else if (nameLower.includes('dầu gội') && (nameLower.includes('gàu') || nameLower.includes('ngứa'))) {
      return 'Dầu gội trị gàu'
    } else if (nameLower.includes('dầu xả') && (nameLower.includes('gàu') || nameLower.includes('ngứa'))) {
      return 'Dầu xả trị gàu'
    } else if (nameLower.includes('dầu gội')) {
      return 'Dầu gội dưỡng tóc'
    } else if (nameLower.includes('dầu xả')) {
      return 'Dầu xả dưỡng tóc'
    }
    
    return 'Sản phẩm chăm sóc tóc'
  }

  private normalizeImageUrl(imageUrl: string): string {
    if (!imageUrl) return '/images/placeholder.jpg'
    
    if (imageUrl.startsWith('//')) {
      return 'https:' + imageUrl
    } else if (imageUrl.startsWith('/')) {
      return this.baseUrl + imageUrl
    }
    
    return imageUrl
  }
}

