import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Utility functions for content generation
export const contentHooks = [
  "Bạn đã từng gặp phải tình trạng tóc bết dầu chỉ sau vài giờ ra đường?",
  "Bí quyết cho mái tóc suôn mượt mà không cần ra salon?",
  "Tại sao tóc bạn luôn thiếu sức sống và bồng bềnh?",
  "Có phải bạn đang tìm kiếm giải pháp cho mái tóc khô xơ?",
  "Bạn có biết rằng việc chăm sóc tóc đúng cách có thể thay đổi hoàn toàn diện mạo?",
  "Mùa hè này, làm sao để tóc luôn tươi mới suốt cả ngày?",
  "Liệu có cách nào để tóc bạn luôn thơm mát như vừa gội?",
  "Bạn có tin rằng chỉ với 1 sản phẩm có thể giải quyết mọi vấn đề về tóc?"
]

export const ctaSuggestions = [
  "Inbox ngay để được tư vấn miễn phí!",
  "Ghé shop ngay để nhận ưu đãi đặc biệt!",
  "Comment 'MUỐN' để được hỗ trợ đặt hàng!",
  "Đặt hàng ngay - Freeship toàn quốc!",
  "Liên hệ hotline để được giá tốt nhất!",
  "Click link để xem thêm sản phẩm!",
  "Mua ngay kẻo lỡ - Số lượng có hạn!",
  "Tag bạn bè để cùng nhận ưu đãi!"
]

export const hashtagSuggestions = {
  "dầu gội khô": ["#daugoi", "#daugoikho", "#chamsoctoc", "#tocbongbenh", "#tocsuonmuot", "#spes", "#daugoitaokieu"],
  "dầu gội": ["#daugoi", "#chamsoctoc", "#tockhoe", "#daugoithiennhien", "#spes", "#tocsuonmuot"],
  "dầu xả": ["#dauxa", "#chamsoctoc", "#tocmuot", "#duongtoc", "#spes", "#tockhoe"],
  "keo xịt": ["#keoxit", "#taokieutoc", "#tocbongbenh", "#giuuep", "#spes", "#tockieu"],
  "trị gàu": ["#trigau", "#chamsoctoc", "#dadau", "#spes", "#tockhoe", "#khonggau"]
}

export const toneOptions = [
  { value: "natural", label: "Tự nhiên" },
  { value: "fun", label: "Vui vẻ" },
  { value: "review", label: "Review" },
  { value: "expert", label: "Chuyên gia" },
  { value: "sales", label: "Kích thích mua hàng" }
]

export function generateHashtags(productName: string, category: string): string[] {
  const baseHashtags = ["#spes", "#chamsoctoc", "#tockhoe"]
  const categoryHashtags = hashtagSuggestions[category.toLowerCase() as keyof typeof hashtagSuggestions] || []
  
  return [...baseHashtags, ...categoryHashtags].slice(0, 8)
}

export function getRandomHook(): string {
  return contentHooks[Math.floor(Math.random() * contentHooks.length)]
}

export function getRandomCTA(): string {
  return ctaSuggestions[Math.floor(Math.random() * ctaSuggestions.length)]
}

