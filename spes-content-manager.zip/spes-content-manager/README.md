# SPES Content Manager

Ứng dụng quản lý sản phẩm và viết content Facebook cho SPES Vietnam - một hệ thống toàn diện giúp tự động hóa quy trình tạo nội dung marketing cho các sản phẩm chăm sóc tóc.

## 🌟 Tính năng chính

### 1. Quản lý sản phẩm
- **Import từ Shopee**: Tự động lấy thông tin sản phẩm từ shop Shopee SPES Vietnam
- **Upload file Excel/CSV**: Hỗ trợ upload danh sách sản phẩm từ file Excel hoặc CSV
- **Quản lý thông tin**: Lưu trữ tên, giá, phân loại, mô tả, hình ảnh và mã SKU
- **Phân loại tự động**: Tự động phân loại sản phẩm dựa trên tên (dầu gội khô, dầu xả, keo xịt...)

### 2. Viết content Facebook
- **Form viết bài chuyên nghiệp**: Giao diện trực quan với các trường thông tin cần thiết
- **Công thức viết bài**: Hỗ trợ 4 công thức phổ biến (AIDA, PAS, 4P, Storytelling)
- **Gợi ý thông minh**: 
  - Hook mở bài thu hút
  - Call-to-Action hiệu quả
  - Hashtag phù hợp với từng loại sản phẩm
- **Tone giọng đa dạng**: Tự nhiên, vui vẻ, review, chuyên gia, kích thích mua hàng

### 3. Quản lý bài viết
- **Lưu trữ lịch sử**: Tất cả bài viết được lưu trữ và có thể truy cập lại
- **Export đa định dạng**: Xuất bài viết ra file .txt hoặc copy nhanh
- **Tìm kiếm và lọc**: Dễ dàng tìm kiếm bài viết theo sản phẩm hoặc thời gian

### 4. Bảo mật và xác thực
- **Google OAuth**: Đăng nhập an toàn bằng tài khoản Google
- **Kiểm soát truy cập**: Chỉ cho phép tài khoản được ủy quyền (manus@gmail.com)
- **Bảo vệ dữ liệu**: Mọi thông tin được mã hóa và bảo mật

### 5. Giao diện hiện đại
- **Responsive design**: Tương thích hoàn hảo trên desktop và mobile
- **Dark mode**: Hỗ trợ chế độ tối để bảo vệ mắt
- **UX/UI tối ưu**: Thiết kế trực quan, dễ sử dụng

## 🛠 Công nghệ sử dụng

- **Frontend**: Next.js 15, React 18, TypeScript
- **Styling**: TailwindCSS, Radix UI
- **Backend**: Next.js API Routes
- **Database**: SQLite với Prisma ORM
- **Authentication**: NextAuth.js với Google OAuth
- **File Processing**: XLSX, Papa Parse
- **Web Scraping**: Axios, Cheerio

## 📋 Yêu cầu hệ thống

- Node.js 18.0 trở lên
- npm hoặc yarn
- Tài khoản Google để cấu hình OAuth
- (Tùy chọn) Tài khoản Vercel để deploy

## 🚀 Hướng dẫn cài đặt

### Bước 1: Clone repository
```bash
git clone <repository-url>
cd spes-content-manager
```

### Bước 2: Cài đặt dependencies
```bash
npm install
```

### Bước 3: Cấu hình biến môi trường
Tạo file `.env.local` trong thư mục gốc:

```env
# Database
DATABASE_URL="file:./dev.db"

# NextAuth.js
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-secret-key-here"

# Google OAuth
GOOGLE_CLIENT_ID="your-google-client-id"
GOOGLE_CLIENT_SECRET="your-google-client-secret"

# Admin access
ADMIN_EMAIL="manus@gmail.com"
```

### Bước 4: Cấu hình Google OAuth

1. Truy cập [Google Cloud Console](https://console.cloud.google.com/)
2. Tạo project mới hoặc chọn project hiện có
3. Bật Google+ API
4. Tạo OAuth 2.0 credentials:
   - Application type: Web application
   - Authorized redirect URIs: `http://localhost:3000/api/auth/callback/google`
5. Copy Client ID và Client Secret vào file `.env.local`

### Bước 5: Khởi tạo database
```bash
npx prisma generate
npx prisma db push
```

### Bước 6: Chạy ứng dụng
```bash
npm run dev
```

Ứng dụng sẽ chạy tại `http://localhost:3000`

## 📁 Cấu trúc thư mục

```
spes-content-manager/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── api/               # API routes
│   │   ├── auth/              # Authentication pages
│   │   ├── content/           # Content creation pages
│   │   └── posts/             # Post management pages
│   ├── components/            # React components
│   │   ├── ui/               # Base UI components
│   │   ├── ContentForm.tsx   # Form viết content
│   │   ├── ProductCard.tsx   # Card hiển thị sản phẩm
│   │   └── ...
│   ├── hooks/                # Custom React hooks
│   ├── lib/                  # Utilities và configurations
│   └── types/                # TypeScript type definitions
├── prisma/                   # Database schema
├── public/                   # Static assets
└── ...
```

## 🎯 Hướng dẫn sử dụng

### 1. Đăng nhập
- Truy cập ứng dụng và click "Đăng nhập với Google"
- Chỉ tài khoản manus@gmail.com mới được phép truy cập

### 2. Thêm sản phẩm

#### Từ Shopee:
1. Click "Import Shopee"
2. Nhập URL shop: `https://shopee.vn/spesvietnam`
3. Click "Import từ Shopee" hoặc "Dùng dữ liệu mẫu"

#### Từ file Excel/CSV:
1. Click "Upload File"
2. Chọn file Excel (.xlsx, .xls) hoặc CSV
3. Đảm bảo file có các cột: `Tên SP`, `Giá`, `Phân loại`

### 3. Viết content Facebook
1. Click "Viết Content" trên card sản phẩm
2. Sử dụng các công cụ hỗ trợ:
   - Gợi ý Hook mở bài
   - Chọn công thức viết bài (AIDA, PAS, 4P, Storytelling)
   - Tạo hashtag tự động
   - Gợi ý CTA
3. Chọn tone giọng phù hợp
4. Lưu bài viết

### 4. Quản lý bài viết
- Xem lịch sử tất cả bài viết tại trang "Quản lý bài viết"
- Copy nhanh nội dung bài viết
- Export ra file .txt
- Xóa hoặc chỉnh sửa bài viết

## 🔧 Tùy chỉnh

### Thêm công thức viết bài mới
Chỉnh sửa file `src/components/ContentForm.tsx`:

```typescript
const contentFormulas = [
  // Thêm công thức mới
  {
    name: 'Tên công thức',
    description: 'Mô tả ngắn',
    template: `Template nội dung...`
  }
]
```

### Thêm gợi ý Hook và CTA
Chỉnh sửa file `src/lib/utils.ts`:

```typescript
export const contentHooks = [
  // Thêm hook mới
  "Hook mới của bạn..."
]

export const ctaSuggestions = [
  // Thêm CTA mới
  "CTA mới của bạn..."
]
```

## 🚀 Deploy lên Vercel

### Bước 1: Chuẩn bị
1. Push code lên GitHub repository
2. Tạo tài khoản Vercel (nếu chưa có)

### Bước 2: Deploy
1. Truy cập [Vercel Dashboard](https://vercel.com/dashboard)
2. Click "New Project"
3. Import GitHub repository
4. Cấu hình biến môi trường:
   - Thêm tất cả biến trong `.env.local`
   - Cập nhật `NEXTAUTH_URL` thành domain Vercel

### Bước 3: Cập nhật Google OAuth
1. Thêm domain Vercel vào Authorized redirect URIs:
   - `https://your-app.vercel.app/api/auth/callback/google`

### Bước 4: Database
- Vercel sẽ tự động chạy `prisma generate` và `prisma db push`
- Database SQLite sẽ được tạo tự động

## 🐛 Troubleshooting

### Lỗi Google OAuth
- Kiểm tra GOOGLE_CLIENT_ID và GOOGLE_CLIENT_SECRET
- Đảm bảo redirect URI được cấu hình đúng
- Kiểm tra email được phép truy cập

### Lỗi Database
```bash
# Reset database
rm prisma/dev.db
npx prisma db push
```

### Lỗi Build
```bash
# Clear cache và rebuild
rm -rf .next
npm run build
```

## 📞 Hỗ trợ

Nếu gặp vấn đề, vui lòng:
1. Kiểm tra logs trong console
2. Đảm bảo tất cả biến môi trường được cấu hình đúng
3. Liên hệ team phát triển

## 📄 License

Dự án này thuộc quyền sở hữu của SPES Vietnam. Mọi quyền được bảo lưu.

---

**Phát triển bởi**: Manus AI  
**Phiên bản**: 1.0.0  
**Cập nhật lần cuối**: 30/06/2025

