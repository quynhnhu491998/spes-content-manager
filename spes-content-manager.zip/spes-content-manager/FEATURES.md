# Tính năng chi tiết - SPES Content Manager

## 📋 Tổng quan tính năng

SPES Content Manager là một hệ thống toàn diện được thiết kế đặc biệt cho SPES Vietnam để tự động hóa và tối ưu hóa quy trình tạo nội dung marketing trên Facebook. Ứng dụng kết hợp quản lý sản phẩm thông minh với công cụ viết content chuyên nghiệp.

## 🛍️ Quản lý sản phẩm

### 1. Import từ Shopee

**Mô tả**: Tự động thu thập thông tin sản phẩm từ shop Shopee SPES Vietnam.

**Tính năng**:
- **URL Shop**: `https://shopee.vn/spesvietnam`
- **Scraping thông minh**: Tự động phân tích cấu trúc trang và trích xuất dữ liệu
- **Phân loại tự động**: Dựa trên tên sản phẩm để phân loại (dầu gội khô, dầu xả, keo xịt...)
- **Xử lý hình ảnh**: Tự động chuẩn hóa URL hình ảnh từ Shopee CDN
- **Dữ liệu mẫu**: Cung cấp dữ liệu mẫu dựa trên sản phẩm SPES thực tế

**Dữ liệu thu thập**:
- Tên sản phẩm
- Giá bán
- Hình ảnh sản phẩm
- Mô tả ngắn
- Link sản phẩm gốc
- Phân loại tự động

**Xử lý lỗi**:
- Fallback về dữ liệu mẫu nếu scraping thất bại
- Retry mechanism cho network errors
- Validation dữ liệu trước khi lưu

### 2. Upload File Excel/CSV

**Mô tả**: Cho phép upload danh sách sản phẩm từ file Excel hoặc CSV.

**Định dạng hỗ trợ**:
- Excel: `.xlsx`, `.xls`
- CSV: `.csv`

**Cấu trúc file yêu cầu**:

| Cột | Tên tiếng Việt | Tên tiếng Anh | Bắt buộc | Mô tả |
|-----|----------------|---------------|----------|-------|
| 1 | Tên SP | Product Name | ✅ | Tên sản phẩm |
| 2 | Giá | Price | ✅ | Giá bán (VD: 150,000đ) |
| 3 | Phân loại | Category | ✅ | Loại sản phẩm |
| 4 | Mô tả | Description | ❌ | Mô tả chi tiết |
| 5 | Ảnh | Image | ❌ | URL hình ảnh |
| 6 | Mã SKU | SKU | ❌ | Mã sản phẩm |

**Tính năng xử lý**:
- **Flexible column mapping**: Tự động nhận diện tên cột tiếng Việt/Anh
- **Data validation**: Kiểm tra dữ liệu bắt buộc
- **Error reporting**: Báo cáo chi tiết lỗi từng dòng
- **Batch processing**: Xử lý hàng loạt sản phẩm
- **Preview before save**: Hiển thị dữ liệu trước khi lưu

**Xử lý lỗi**:
- Báo cáo dòng có lỗi cụ thể
- Tiếp tục xử lý các dòng hợp lệ
- Thống kê kết quả import

### 3. Hiển thị và quản lý

**Grid Layout**:
- **Responsive design**: Tự động điều chỉnh số cột theo màn hình
- **Card-based UI**: Mỗi sản phẩm hiển thị trong card riêng biệt
- **Hover effects**: Hiệu ứng khi di chuột qua card

**Thông tin hiển thị**:
- Hình ảnh sản phẩm (với fallback placeholder)
- Tên sản phẩm (line-clamp để tránh quá dài)
- Giá bán (highlight màu xanh)
- Phân loại (badge)
- Nguồn dữ liệu (Shopee/File)

**Tính năng tương tác**:
- **Viết Content**: Chuyển đến form viết bài
- **Sửa**: Chỉnh sửa thông tin sản phẩm
- **Xem**: Mở link sản phẩm gốc (nếu có)
- **Xóa**: Xóa sản phẩm khỏi hệ thống

### 4. Tìm kiếm và lọc

**Tìm kiếm**:
- **Real-time search**: Tìm kiếm ngay khi gõ
- **Multi-field search**: Tìm trong tên và phân loại
- **Case-insensitive**: Không phân biệt hoa thường

**Lọc theo danh mục**:
- Dropdown hiển thị tất cả danh mục có sẵn
- Tự động cập nhật khi thêm sản phẩm mới
- Kết hợp được với tìm kiếm

## ✍️ Viết Content Facebook

### 1. Form viết bài chuyên nghiệp

**Layout thông minh**:
- **2-column layout**: Form chính bên trái, công cụ hỗ trợ bên phải
- **Responsive**: Tự động chuyển 1 cột trên mobile
- **Auto-save**: Tự động lưu draft (localStorage)

**Các trường thông tin**:

#### Tiêu đề Facebook
- **Input field**: Text input với placeholder gợi ý
- **Hook generator**: Button tạo hook tự động
- **Character counter**: Đếm ký tự để tối ưu độ dài

#### Nội dung bài viết
- **Large textarea**: 12 rows, có thể resize
- **Rich text support**: Hỗ trợ emoji, line breaks
- **Template insertion**: Chèn template từ công thức

#### Tone giọng
- **Dropdown selection**: 5 lựa chọn tone
- **Preview impact**: Hiển thị ảnh hưởng của tone lên content

#### Hashtags
- **Tag management**: Thêm/xóa hashtag dễ dàng
- **Auto-generation**: Tự động tạo hashtag phù hợp
- **Popular suggestions**: Gợi ý hashtag phổ biến

#### Call to Action
- **Textarea**: Cho phép CTA dài
- **Template library**: Thư viện CTA mẫu
- **A/B testing suggestions**: Gợi ý test nhiều CTA

### 2. Công thức viết bài

#### AIDA (Attention - Interest - Desire - Action)
```
🔥 [Hook thu hút sự chú ý]

💡 [Giải thích lợi ích và tạo hứng thú]

✨ [Tạo mong muốn sở hữu sản phẩm]

👉 [Call to Action rõ ràng]
```

**Ứng dụng cho SPES**:
- **Attention**: Câu hỏi về vấn đề tóc
- **Interest**: Giới thiệu sản phẩm và lợi ích
- **Desire**: Mô tả kết quả sau khi sử dụng
- **Action**: Kêu gọi mua hàng/inbox

#### PAS (Problem - Agitate - Solution)
```
😰 [Nêu vấn đề khách hàng gặp phải]

💔 [Khuếch đại vấn đề, tạo cảm xúc]

🌟 [Giới thiệu sản phẩm như giải pháp]

👉 [Call to Action]
```

**Ứng dụng cho SPES**:
- **Problem**: Tóc bết dầu, khô xơ, gàu...
- **Agitate**: Ảnh hưởng đến tự tin, hình ảnh
- **Solution**: Sản phẩm SPES giải quyết

#### 4P (Promise - Picture - Proof - Push)
```
🎯 [Lời hứa về kết quả]

🖼️ [Mô tả hình ảnh tương lai tích cực]

✅ [Bằng chứng, chứng minh]

🚀 [Thúc đẩy hành động ngay]
```

#### Storytelling
```
📖 [Mở đầu câu chuyện]

🎭 [Phát triển tình huống, xung đột]

🌈 [Giải quyết bằng sản phẩm]

💝 [Kết thúc có ý nghĩa + CTA]
```

### 3. Hệ thống gợi ý thông minh

#### Hook mở bài
**Database hooks**:
- "Bạn đã từng gặp phải tình trạng tóc bết dầu chỉ sau vài giờ ra đường?"
- "Bí quyết cho mái tóc suôn mượt mà không cần ra salon?"
- "Tại sao tóc bạn luôn thiếu sức sống và bồng bềnh?"
- "Có phải bạn đang tìm kiếm giải pháp cho mái tóc khô xơ?"

**Personalization**:
- Dựa trên loại sản phẩm để gợi ý hook phù hợp
- Random selection để tránh lặp lại
- Có thể customize theo mùa/trend

#### CTA suggestions
**Conversion-focused**:
- "Inbox ngay để được tư vấn miễn phí!"
- "Ghé shop ngay để nhận ưu đãi đặc biệt!"
- "Comment 'MUỐN' để được hỗ trợ đặt hàng!"
- "Đặt hàng ngay - Freeship toàn quốc!"

**Engagement-focused**:
- "Tag bạn bè để cùng nhận ưu đãi!"
- "Share để lưu lại công thức chăm sóc tóc!"
- "Comment trải nghiệm của bạn bên dưới!"

#### Hashtag generation
**Algorithm**:
```typescript
function generateHashtags(productName: string, category: string): string[] {
  const baseHashtags = ["#spes", "#chamsoctoc", "#tockhoe"]
  const categoryHashtags = hashtagSuggestions[category.toLowerCase()]
  
  return [...baseHashtags, ...categoryHashtags].slice(0, 8)
}
```

**Category mapping**:
- **Dầu gội khô**: #daugoikho #tocbongbenh #taokieu
- **Dầu gội**: #daugoi #tocsuonmuot #thiennhien
- **Dầu xả**: #dauxa #duongtoc #tocmuot
- **Keo xịt**: #keoxit #giuuep #tockieu

### 4. Tone giọng đa dạng

#### Tự nhiên
- Ngôn ngữ thân thiện, gần gũi
- Chia sẻ kinh nghiệm cá nhân
- Tránh thuật ngữ phức tạp

#### Vui vẻ
- Sử dụng emoji nhiều
- Ngôn ngữ năng động, tích cực
- Tạo cảm giác vui tươi

#### Review
- Đánh giá khách quan
- So sánh với sản phẩm khác
- Chia sẻ ưu/nhược điểm

#### Chuyên gia
- Sử dụng thuật ngữ chuyên môn
- Giải thích cơ chế hoạt động
- Dẫn chứng khoa học

#### Kích thích mua hàng
- Tạo cảm giác khan hiếm
- Nhấn mạnh ưu đãi
- Call-to-action mạnh mẽ

## 📚 Quản lý bài viết

### 1. Lưu trữ và tổ chức

**Database schema**:
```sql
Post {
  id: String (UUID)
  title: String
  content: String (Long text)
  hashtags: String
  tone: String
  cta: String
  productId: String (Foreign key)
  userId: String (Foreign key)
  createdAt: DateTime
  updatedAt: DateTime
}
```

**Indexing**:
- Index trên userId để query nhanh
- Index trên productId để lọc theo sản phẩm
- Index trên createdAt để sắp xếp

### 2. Hiển thị lịch sử

**List view**:
- **Chronological order**: Mới nhất lên đầu
- **Expandable cards**: Click để xem chi tiết
- **Quick actions**: Copy, export, edit, delete

**Thông tin hiển thị**:
- Tiêu đề bài viết
- Sản phẩm liên quan
- Thời gian tạo (relative time)
- Tone giọng (badge)
- Preview nội dung

### 3. Export và chia sẻ

#### Copy to clipboard
```typescript
const fullContent = `${title}\n\n${content}\n\n${hashtags}\n\n${cta}`
navigator.clipboard.writeText(fullContent)
```

#### Export to .txt
```typescript
const blob = new Blob([fullContent], { type: 'text/plain' })
const url = URL.createObjectURL(blob)
// Trigger download
```

**File format**:
```
Tiêu đề: [Title]

Nội dung:
[Content]

Hashtags: [Hashtags]

Tone: [Tone]

CTA: [CTA]

Sản phẩm: [Product Name]
Giá: [Price]
Danh mục: [Category]

Tạo lúc: [Timestamp]
```

### 4. Tìm kiếm và lọc

**Search functionality**:
- Tìm trong tiêu đề và nội dung
- Real-time search
- Highlight kết quả

**Filter options**:
- Theo sản phẩm
- Theo tone giọng
- Theo thời gian tạo
- Theo độ dài nội dung

## 🔐 Bảo mật và xác thực

### 1. Google OAuth Integration

**NextAuth.js configuration**:
```typescript
providers: [
  GoogleProvider({
    clientId: process.env.GOOGLE_CLIENT_ID!,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
  }),
]
```

**Access control**:
```typescript
async signIn({ user }) {
  return user.email === process.env.ADMIN_EMAIL
}
```

### 2. Session management

**Database sessions**:
- Persistent sessions trong database
- Automatic cleanup expired sessions
- Secure session tokens

**User context**:
```typescript
const { data: session } = useSession()
// session.user.id, session.user.email, session.user.name
```

### 3. API protection

**Middleware protection**:
```typescript
const session = await getServerSession(authOptions)
if (!session?.user?.email) {
  return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
}
```

**Admin-only endpoints**:
- Upload file
- Shopee import
- Bulk operations

## 🎨 UI/UX Design

### 1. Design System

**Color palette**:
- Primary: Blue (#3B82F6)
- Secondary: Purple (#8B5CF6)
- Success: Green (#10B981)
- Warning: Orange (#F59E0B)
- Error: Red (#EF4444)

**Typography**:
- Font family: Inter
- Heading: 24px, 20px, 18px, 16px
- Body: 16px, 14px
- Caption: 12px

### 2. Component Library

**Base components**:
- Button (5 variants, 4 sizes)
- Input (text, email, password, file)
- Textarea (auto-resize)
- Select (searchable, multi-select)
- Card (header, content, footer)
- Badge (status indicators)

**Composite components**:
- ProductCard
- ContentForm
- FileUpload
- PostHistory

### 3. Responsive Design

**Breakpoints**:
- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px

**Grid system**:
- Mobile: 1 column
- Tablet: 2-3 columns
- Desktop: 4 columns

### 4. Dark Mode

**Implementation**:
- CSS variables cho colors
- System preference detection
- Manual toggle
- Persistent preference

**Theme switching**:
```typescript
const { theme, setTheme } = useTheme()
setTheme(theme === 'light' ? 'dark' : 'light')
```

## 📱 Mobile Optimization

### 1. Touch-friendly Interface

**Button sizing**:
- Minimum 44px touch target
- Adequate spacing between elements
- Swipe gestures support

**Navigation**:
- Bottom navigation on mobile
- Hamburger menu for secondary actions
- Breadcrumb navigation

### 2. Performance

**Image optimization**:
- Next.js Image component
- Lazy loading
- WebP format support
- Responsive images

**Code splitting**:
- Route-based splitting
- Component lazy loading
- Dynamic imports

### 3. PWA Features

**Manifest.json**:
```json
{
  "name": "SPES Content Manager",
  "short_name": "SPES CM",
  "description": "Content management for SPES Vietnam",
  "start_url": "/",
  "display": "standalone",
  "theme_color": "#3B82F6",
  "background_color": "#FFFFFF"
}
```

## 🔧 Extensibility

### 1. Plugin Architecture

**Hook system**:
```typescript
// Custom hooks for extending functionality
export const useContentSuggestions = (product: Product) => {
  // Custom logic for content suggestions
}
```

### 2. Configuration

**Environment-based config**:
```typescript
const config = {
  shopee: {
    baseUrl: process.env.SHOPEE_BASE_URL,
    timeout: parseInt(process.env.SCRAPING_TIMEOUT || '30000')
  },
  content: {
    maxHashtags: parseInt(process.env.MAX_HASHTAGS || '8'),
    maxContentLength: parseInt(process.env.MAX_CONTENT_LENGTH || '2000')
  }
}
```

### 3. API Extensions

**Webhook support**:
```typescript
// POST /api/webhooks/content-created
export async function POST(request: NextRequest) {
  const { postId, productId } = await request.json()
  // Trigger external integrations
}
```

---

**Tài liệu này mô tả đầy đủ các tính năng của SPES Content Manager phiên bản 1.0.0**  
**Cập nhật lần cuối**: 30/06/2025

