# Hướng dẫn Deploy SPES Content Manager

## 🎯 Tổng quan

Tài liệu này cung cấp hướng dẫn chi tiết để deploy ứng dụng SPES Content Manager lên Vercel, bao gồm cấu hình Google OAuth, database và các biến môi trường.

## 📋 Checklist trước khi deploy

- [ ] Code đã được test kỹ lưỡng ở local
- [ ] Tất cả dependencies đã được cài đặt
- [ ] File `.env.local` đã được cấu hình đầy đủ
- [ ] Google OAuth đã được thiết lập
- [ ] Repository đã được push lên GitHub

## 🚀 Deploy lên Vercel

### Bước 1: Chuẩn bị Repository

1. **Push code lên GitHub**:
```bash
git add .
git commit -m "Ready for deployment"
git push origin main
```

2. **Đảm bảo file cần thiết**:
   - `package.json` với scripts build
   - `next.config.js` (nếu có)
   - `vercel.json` (tùy chọn)

### Bước 2: Tạo Project trên Vercel

1. Truy cập [Vercel Dashboard](https://vercel.com/dashboard)
2. Click **"New Project"**
3. Import repository từ GitHub
4. Chọn repository `spes-content-manager`
5. Cấu hình project:
   - **Framework Preset**: Next.js
   - **Root Directory**: `./` (mặc định)
   - **Build Command**: `npm run build` (mặc định)
   - **Output Directory**: `.next` (mặc định)

### Bước 3: Cấu hình Environment Variables

Trong phần **Environment Variables** của Vercel, thêm các biến sau:

```env
# Database
DATABASE_URL=file:./dev.db

# NextAuth.js
NEXTAUTH_URL=https://your-app-name.vercel.app
NEXTAUTH_SECRET=your-super-secret-key-here-minimum-32-characters

# Google OAuth
GOOGLE_CLIENT_ID=your-google-client-id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your-google-client-secret

# Admin Access
ADMIN_EMAIL=manus@gmail.com
```

**Lưu ý quan trọng**:
- `NEXTAUTH_URL` phải là domain chính xác của ứng dụng trên Vercel
- `NEXTAUTH_SECRET` nên là chuỗi ngẫu nhiên ít nhất 32 ký tự
- Có thể generate secret bằng: `openssl rand -base64 32`

### Bước 4: Deploy

1. Click **"Deploy"**
2. Chờ quá trình build hoàn thành (thường 2-5 phút)
3. Kiểm tra logs nếu có lỗi

## 🔐 Cấu hình Google OAuth cho Production

### Bước 1: Cập nhật Google Cloud Console

1. Truy cập [Google Cloud Console](https://console.cloud.google.com/)
2. Chọn project đã tạo trước đó
3. Vào **APIs & Services > Credentials**
4. Chọn OAuth 2.0 Client ID đã tạo
5. Thêm **Authorized redirect URIs**:
   ```
   https://your-app-name.vercel.app/api/auth/callback/google
   ```
6. Thêm **Authorized JavaScript origins**:
   ```
   https://your-app-name.vercel.app
   ```

### Bước 2: Kiểm tra cấu hình

1. Truy cập ứng dụng trên domain Vercel
2. Thử đăng nhập bằng Google
3. Kiểm tra xem có redirect đúng không

## 🗄️ Database Configuration

### SQLite trên Vercel

Vercel hỗ trợ SQLite cho development, nhưng có một số hạn chế:

1. **File database sẽ bị reset** sau mỗi lần deploy
2. **Không persistent** giữa các function calls
3. **Chỉ phù hợp cho demo/testing**

### Khuyến nghị cho Production

Để sử dụng production, nên chuyển sang database cloud:

#### Option 1: PlanetScale (MySQL)
```env
DATABASE_URL="mysql://username:password@host/database?sslaccept=strict"
```

#### Option 2: Supabase (PostgreSQL)
```env
DATABASE_URL="postgresql://username:password@host:port/database"
```

#### Option 3: Railway (PostgreSQL)
```env
DATABASE_URL="postgresql://username:password@host:port/database"
```

### Migration cho Production Database

1. **Cập nhật schema.prisma**:
```prisma
datasource db {
  provider = "postgresql" // hoặc "mysql"
  url      = env("DATABASE_URL")
}
```

2. **Chạy migration**:
```bash
npx prisma migrate dev --name init
npx prisma generate
```

3. **Deploy với database mới**:
```bash
npx prisma db push
```

## ⚙️ Cấu hình nâng cao

### Vercel.json Configuration

Tạo file `vercel.json` để tùy chỉnh deployment:

```json
{
  "framework": "nextjs",
  "buildCommand": "npm run build",
  "devCommand": "npm run dev",
  "installCommand": "npm install",
  "functions": {
    "src/app/api/**/*.ts": {
      "maxDuration": 30
    }
  },
  "env": {
    "NODE_ENV": "production"
  }
}
```

### Next.js Configuration

Cập nhật `next.config.js` nếu cần:

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverComponentsExternalPackages: ['@prisma/client', 'prisma']
  },
  images: {
    domains: ['cf.shopee.vn', 'down-vn.img.susercontent.com'],
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.shopee.vn',
      },
    ],
  },
}

module.exports = nextConfig
```

## 🔍 Monitoring và Debugging

### Vercel Analytics

1. Bật **Vercel Analytics** trong dashboard
2. Monitor performance và usage
3. Kiểm tra error rates

### Logging

Sử dụng `console.log` trong API routes để debug:

```typescript
export async function POST(request: NextRequest) {
  console.log('API called:', request.url)
  // ... logic
}
```

Logs có thể xem trong **Vercel Dashboard > Functions > View Function Logs**

### Error Handling

Đảm bảo tất cả API routes có error handling:

```typescript
try {
  // ... logic
} catch (error) {
  console.error('Error:', error)
  return NextResponse.json(
    { error: 'Internal server error' }, 
    { status: 500 }
  )
}
```

## 🔄 CI/CD Pipeline

### Automatic Deployments

Vercel tự động deploy khi:
- Push code lên branch `main`
- Merge pull request
- Manual trigger từ dashboard

### Preview Deployments

Mỗi pull request sẽ tạo preview deployment:
- URL dạng: `https://spes-content-manager-git-branch-username.vercel.app`
- Có thể test trước khi merge

### Branch Protection

Cấu hình GitHub để require:
- Pull request reviews
- Status checks pass
- Branch up to date

## 🛡️ Security Best Practices

### Environment Variables

1. **Không commit** `.env` files
2. **Sử dụng secrets** cho sensitive data
3. **Rotate keys** định kỳ

### CORS Configuration

Nếu cần CORS, cấu hình trong API routes:

```typescript
export async function GET(request: NextRequest) {
  const response = NextResponse.json(data)
  
  response.headers.set('Access-Control-Allow-Origin', 'https://your-domain.com')
  response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE')
  
  return response
}
```

### Rate Limiting

Implement rate limiting cho API:

```typescript
import { Ratelimit } from "@upstash/ratelimit"
import { Redis } from "@upstash/redis"

const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(10, "10 s"),
})
```

## 📊 Performance Optimization

### Image Optimization

Sử dụng Next.js Image component:

```tsx
import Image from 'next/image'

<Image
  src={product.image}
  alt={product.name}
  width={300}
  height={300}
  priority={index < 4} // Prioritize first 4 images
/>
```

### Bundle Analysis

Analyze bundle size:

```bash
npm install --save-dev @next/bundle-analyzer
```

```javascript
// next.config.js
const withBundleAnalyzer = require('@next/bundle-analyzer')({
  enabled: process.env.ANALYZE === 'true',
})

module.exports = withBundleAnalyzer(nextConfig)
```

### Caching Strategy

Implement caching cho API responses:

```typescript
export async function GET() {
  const data = await fetchData()
  
  return NextResponse.json(data, {
    headers: {
      'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=300'
    }
  })
}
```

## 🚨 Troubleshooting

### Common Issues

1. **Build Failures**:
   - Check TypeScript errors
   - Verify all imports
   - Check environment variables

2. **OAuth Errors**:
   - Verify redirect URIs
   - Check client ID/secret
   - Ensure NEXTAUTH_URL is correct

3. **Database Errors**:
   - Check DATABASE_URL format
   - Verify Prisma schema
   - Run migrations

4. **API Timeouts**:
   - Increase function timeout in vercel.json
   - Optimize database queries
   - Add error handling

### Debug Commands

```bash
# Local debugging
npm run build
npm run start

# Check environment
npx next info

# Database debugging
npx prisma studio
npx prisma db pull
```

## 📈 Post-Deployment Checklist

- [ ] Ứng dụng load thành công
- [ ] Google OAuth hoạt động
- [ ] Có thể đăng nhập với manus@gmail.com
- [ ] Upload file Excel/CSV hoạt động
- [ ] Import Shopee hoạt động (hoặc dữ liệu mẫu)
- [ ] Tạo content Facebook hoạt động
- [ ] Lưu và quản lý bài viết hoạt động
- [ ] Dark mode hoạt động
- [ ] Responsive trên mobile
- [ ] Performance tốt (< 3s load time)

## 🔄 Maintenance

### Regular Tasks

1. **Update dependencies** hàng tháng:
```bash
npm update
npm audit fix
```

2. **Monitor performance** qua Vercel Analytics

3. **Backup database** (nếu sử dụng external DB)

4. **Review logs** để phát hiện lỗi

### Scaling Considerations

Khi ứng dụng phát triển:
- Chuyển sang database riêng biệt
- Implement Redis cho caching
- Sử dụng CDN cho static assets
- Consider microservices architecture

---

**Tài liệu này được cập nhật**: 30/06/2025  
**Phiên bản**: 1.0.0

